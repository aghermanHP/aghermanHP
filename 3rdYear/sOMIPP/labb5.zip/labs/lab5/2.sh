ps -Ao pid,time >2.txt
sed -n '$p' /home/gherman/Documents/aghermanHP/3rdYear/sOMIPP/labs/Lab5/2.txt > 22.txt
exit 0