 ps  -eo ProcessID=%p"  ":"  "ParentProcesID=%P" ":" "Average_Time= -eo %mem   --sort +ppid
